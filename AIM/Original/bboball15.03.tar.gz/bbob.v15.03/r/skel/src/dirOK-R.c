/*
 * R implementation of dirOK.
 *
 * Is a no-op because R ensures all required directories exist.
 */
void dirOK(char *sDir) {
    return;
}
