#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Black-Box Optimization Benchmarking (BBOB) comparing two algorithms
post-processing tool:

Contains routines for the comparison of two algorithms.

"""
