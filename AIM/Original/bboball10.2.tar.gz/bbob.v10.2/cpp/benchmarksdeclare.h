#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif

#ifdef DEFINE_GLOBALS
#define GLOBAL
#else // !DEFINE_GLOBALS
#define GLOBAL extern
#define DEFINE_GLOBALS 1
#endif

GLOBAL long int idum;
GLOBAL long int idum2;
/*Global declarations */
GLOBAL unsigned int DIM;
GLOBAL int trialid;
GLOBAL double * peaks;
GLOBAL double * Xopt;
GLOBAL double Fopt;
GLOBAL unsigned int isInitDone;


