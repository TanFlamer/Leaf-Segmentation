
TwoDoubles f1(double* x);
TwoDoubles f2(double* x);
TwoDoubles f3(double* x);
TwoDoubles f4(double* x);
TwoDoubles f5(double* x);
TwoDoubles f6(double* x);
TwoDoubles f7(double* x);
TwoDoubles f8(double* x);
TwoDoubles f9(double* x);
TwoDoubles f10(double* x);
TwoDoubles f11(double* x);
TwoDoubles f12(double* x);
TwoDoubles f13(double* x);
TwoDoubles f14(double* x);
TwoDoubles f15(double* x);
TwoDoubles f16(double* x);
TwoDoubles f17(double* x);
TwoDoubles f18(double* x);
TwoDoubles f19(double* x);
TwoDoubles f20(double* x);
TwoDoubles f21(double* x);
TwoDoubles f22(double* x);
TwoDoubles f23(double* x);
TwoDoubles f24(double* x);

void initbenchmarks();
void finibenchmarks();

bbobFunction handles[24] = { &f1, &f2, &f3, &f4, &f5, &f6, &f7, &f8, &f9, &f10, &f11, &f12, &f13, &f14, &f15, &f16, &f17, &f18, &f19, &f20, &f21, &f22, &f23, &f24};
unsigned int handlesLength = 24;
