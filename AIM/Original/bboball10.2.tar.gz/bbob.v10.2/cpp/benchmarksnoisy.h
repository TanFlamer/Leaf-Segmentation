
TwoDoubles f101(double* x);
TwoDoubles f102(double* x);
TwoDoubles f103(double* x);
TwoDoubles f104(double* x);
TwoDoubles f105(double* x);
TwoDoubles f106(double* x);
TwoDoubles f107(double* x);
TwoDoubles f108(double* x);
TwoDoubles f109(double* x);
TwoDoubles f110(double* x);
TwoDoubles f111(double* x);
TwoDoubles f112(double* x);
TwoDoubles f113(double* x);
TwoDoubles f114(double* x);
TwoDoubles f115(double* x);
TwoDoubles f116(double* x);
TwoDoubles f117(double* x);
TwoDoubles f118(double* x);
TwoDoubles f119(double* x);
TwoDoubles f120(double* x);
TwoDoubles f121(double* x);
TwoDoubles f122(double* x);
TwoDoubles f123(double* x);
TwoDoubles f124(double* x);
TwoDoubles f125(double* x);
TwoDoubles f126(double* x);
TwoDoubles f127(double* x);
TwoDoubles f128(double* x);
TwoDoubles f129(double* x);
TwoDoubles f130(double* x);

void initbenchmarksnoisy();
void finibenchmarksnoisy();

bbobFunction handlesNoisy[30] = { &f101, &f102, &f103, &f104, &f105, &f106, &f107, &f108, &f109, &f110, &f111, &f112, &f113, &f114, &f115, &f116, &f117, &f118, &f119, &f120, &f121, &f122, &f123, &f124, &f125, &f126, &f127, &f128, &f129, &f130};
unsigned int handlesNoisyLength = 30;
