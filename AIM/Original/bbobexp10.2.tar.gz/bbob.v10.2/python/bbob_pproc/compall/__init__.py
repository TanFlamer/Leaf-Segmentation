#!/usr/bin/env python
# coding: utf-8

"""Black-Box Optimization Benchmarking (BBOB) comparing multiple algorithms
post processing tool:

Contains routines for the comparison of multiple algorithms.

"""
